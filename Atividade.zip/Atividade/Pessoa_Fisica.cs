namespace Atividade
{
    class Pessoa_Fisica : Clientes
    //:(dois pontos) significa pessoa fisica herda os elementos de clientes. 
    //subclasse de Cientes. Não precisa reencrever os atributos novamente pq ela herda tudo 
    {
        public string cpf {get; set;}
        public string rg {get; set;}
    }
}